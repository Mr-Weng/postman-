package com.ssm.model;

import lombok.Data;

@Data
public class STU {

    private String name;
    private String sex;
    private String age;
}
